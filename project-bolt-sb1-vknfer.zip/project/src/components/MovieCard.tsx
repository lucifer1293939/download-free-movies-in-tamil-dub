import React from 'react';
import { Play, Star } from 'lucide-react';

interface MovieProps {
  movie: {
    title: string;
    year: number;
    rating: number;
    language: string;
    image: string;
    quality: string;
  };
}

const MovieCard: React.FC<MovieProps> = ({ movie }) => {
  return (
    <div className="group relative overflow-hidden rounded-xl bg-gray-800 transition-transform hover:-translate-y-1">
      <div className="aspect-[2/3] relative">
        <img
          src={movie.image}
          alt={movie.title}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="absolute bottom-0 p-4 w-full">
            <button className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg flex items-center justify-center gap-2 transition-colors">
              <Play size={18} />
              Watch Now
            </button>
          </div>
        </div>
        <div className="absolute top-2 right-2 bg-purple-600 text-white text-sm px-2 py-1 rounded">
          {movie.quality}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1 text-white">{movie.title}</h3>
        <div className="flex items-center justify-between text-sm text-gray-400">
          <span>{movie.year}</span>
          <div className="flex items-center gap-1">
            <Star size={14} className="text-yellow-400 fill-yellow-400" />
            <span>{movie.rating}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MovieCard;