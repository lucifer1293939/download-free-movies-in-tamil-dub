import React from 'react';
import { Home, Film, Flame, Clock, Star, Settings, Heart } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
  const menuItems = [
    { icon: Home, label: 'Home' },
    { icon: Flame, label: 'Trending' },
    { icon: Film, label: 'New Releases' },
    { icon: Clock, label: 'Coming Soon' },
    { icon: Star, label: 'Top Rated' },
    { icon: Heart, label: 'Watchlist' },
    { icon: Settings, label: 'Settings' },
  ];

  return (
    <div
      className={`fixed top-0 left-0 h-full w-64 bg-gray-800 transform transition-transform duration-300 ease-in-out z-40
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}
    >
      {/* Logo */}
      <div className="p-6 border-b border-gray-700">
        <div className="flex items-center gap-2">
          <Film className="text-purple-500" size={24} />
          <span className="text-xl font-bold">MovieHub</span>
        </div>
      </div>

      {/* Menu Items */}
      <nav className="p-4">
        {menuItems.map((item, index) => (
          <button
            key={index}
            onClick={() => setIsOpen(false)}
            className="w-full flex items-center gap-4 px-4 py-3 text-gray-300 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      {/* Language Filter */}
      <div className="absolute bottom-0 w-full p-4 border-t border-gray-700">
        <div className="flex flex-wrap gap-2">
          {['Tamil', 'Telugu', 'Malayalam', 'Hindi'].map((lang) => (
            <button
              key={lang}
              className="px-3 py-1 text-sm bg-gray-700 hover:bg-gray-600 rounded-full transition-colors"
            >
              {lang}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Sidebar;