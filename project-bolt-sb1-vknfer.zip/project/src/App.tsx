import React, { useState } from 'react';
import { Search, Film, Flame, Clock, Star, Menu, X } from 'lucide-react';
import MovieCard from './components/MovieCard';
import Sidebar from './components/Sidebar';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const movies = [
    {
      id: 1,
      title: "Leo",
      year: 2023,
      rating: 8.1,
      language: "Tamil",
      image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&q=80&w=600&h=900",
      quality: "4K"
    },
    {
      id: 2,
      title: "Captain Miller",
      year: 2024,
      rating: 7.8,
      language: "Tamil",
      image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=600&h=900",
      quality: "HD"
    },
    {
      id: 3,
      title: "Ayalaan",
      year: 2024,
      rating: 7.5,
      language: "Tamil",
      image: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?auto=format&fit=crop&q=80&w=600&h=900",
      quality: "HD"
    },
    {
      id: 4,
      title: "Japan",
      year: 2023,
      rating: 7.2,
      language: "Tamil",
      image: "https://images.unsplash.com/photo-1535016120720-40c646be5580?auto=format&fit=crop&q=80&w=600&h=900",
      quality: "4K"
    },
    {
      id: 5,
      title: "Mark Antony",
      year: 2023,
      rating: 7.9,
      language: "Tamil",
      image: "https://images.unsplash.com/photo-1515634928627-2a4e0dae3ddf?auto=format&fit=crop&q=80&w=600&h=900",
      quality: "HD"
    },
    {
      id: 6,
      title: "Jigarthanda 2",
      year: 2023,
      rating: 8.3,
      language: "Tamil",
      image: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80&w=600&h=900",
      quality: "4K"
    }
  ];

  const filteredMovies = movies.filter(movie =>
    movie.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Mobile Menu Button */}
      <button 
        onClick={() => setIsMenuOpen(!isMenuOpen)}
        className="lg:hidden fixed top-4 right-4 z-50 p-2 bg-gray-800 rounded-full"
      >
        {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <Sidebar isOpen={isMenuOpen} setIsOpen={setIsMenuOpen} />

      {/* Main Content */}
      <div className="lg:ml-64 p-6">
        {/* Search Bar */}
        <div className="relative max-w-2xl mx-auto mb-8">
          <input
            type="text"
            placeholder="Search movies..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-gray-800 rounded-full py-3 px-6 pl-12 focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Search className="absolute left-4 top-3.5 text-gray-400" size={20} />
        </div>

        {/* Featured Section */}
        <div className="mb-12 relative overflow-hidden rounded-2xl">
          <img 
            src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1920"
            alt="Featured Movie"
            className="w-full h-[500px] object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/70 to-transparent">
            <div className="absolute bottom-0 p-8">
              <h1 className="text-4xl font-bold mb-2">Captain Miller</h1>
              <p className="text-gray-300 mb-4 max-w-2xl">
                Experience the epic tale of Captain Miller in this action-packed adventure.
                Watch in stunning 4K quality with Dolby Atmos sound.
              </p>
              <button className="bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-full font-semibold transition-colors">
                Watch Now
              </button>
            </div>
          </div>
        </div>

        {/* Movies Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredMovies.map(movie => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;